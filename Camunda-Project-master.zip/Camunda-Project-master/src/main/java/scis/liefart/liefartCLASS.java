package scis.liefart;

import org.camunda.bpm.application.ProcessApplication;
import org.camunda.bpm.application.impl.ServletProcessApplication;


@ProcessApplication("Liefartikel App")
public class liefartCLASS extends ServletProcessApplication {

}
